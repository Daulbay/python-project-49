### Hexlet tests and linter status:
[![Actions Status](https://github.com/Daulbay/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Daulbay/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/2018164b1f5ed622badb/maintainability)](https://codeclimate.com/github/Daulbay/python-project-49/maintainability)

Brain-even: https://asciinema.org/a/S1QjFFMvGj6bMtWGrHkXkrZMb

Brain-calc: https://asciinema.org/a/JeoMXNCVdfIFgaeFXanyVquBY

Brain-gcd: https://asciinema.org/a/qUMGl4AiFALl4vwkMB3tRPV84

brain-progression: https://asciinema.org/a/NO7chqvPVmSbI5X9rwP66amZG