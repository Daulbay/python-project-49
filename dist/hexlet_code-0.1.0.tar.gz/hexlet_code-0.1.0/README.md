### Hexlet tests and linter status:
[![Actions Status](https://github.com/Daulbay/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Daulbay/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/2018164b1f5ed622badb/maintainability)](https://codeclimate.com/github/Daulbay/python-project-49/maintainability)

Brain-even: https://asciinema.org/a/BpPed7NZE2ix0qsEdgQtK5OgE

Brain-calc: https://asciinema.org/a/81wxeGMhEvCWcrC3GGnzLhIWA

Brain-gcd: https://asciinema.org/a/UYyRUQlnfXyABAnj4yt3Hvy92

brain-progression: https://asciinema.org/a/7I1d0uMU6GCjcywcXyVA5SVQU

brain-prime: https://asciinema.org/a/RY8rdfRqQkJIMsbycvC4TvwGS